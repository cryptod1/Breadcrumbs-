BREADCRUMBS V15 — SECURE AUTHORITATIVE RESOLVER

What V15 adds
- GitHub Pages front end remains public.
- OS API key is NEVER placed in index.html.
- A serverless Worker calls OS Places API /find.
- Query uses: property name + postcode.
- Results are restricted to the exact postcode.
- Breadcrumbs only verifies a destination when exactly ONE authoritative address matches the property name and supplies UPRN + WGS84 coordinates.
- Zero matches or multiple matches keep navigation locked.

FILES
index.html      GitHub Pages front end
worker.js       Secure serverless resolver
wrangler.toml   Cloudflare Worker configuration

SETUP
1. Create an OS Data Hub project with access to OS Places API.
2. Obtain the project API key.
3. Deploy worker.js as a Cloudflare Worker (or adapt the same code to another serverless host).
4. Store the key as the Worker secret OS_API_KEY. Never paste it into index.html.
5. Copy the deployed Worker URL.
6. In index.html replace:
   https://YOUR-WORKER.workers.dev/api/resolve
   with:
   https://your-real-worker.workers.dev/api/resolve
7. Upload index.html to the Breadcrumbs- GitHub repository.

EXPECTED CARTREF TEST
Input:
Cartref
CF32 0SD

If OS Places returns one exact Cartref record for that postcode, V15 will show:
Exact destination verified
UPRN
Latitude / longitude
and unlock navigation.

If OS Places returns zero or multiple exact records, V15 deliberately keeps navigation locked.

SECURITY
Do not commit OS_API_KEY to GitHub.
