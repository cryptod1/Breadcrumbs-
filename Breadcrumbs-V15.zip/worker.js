export default {
  async fetch(request, env) {
    const allowedOrigin = env.ALLOWED_ORIGIN || "https://cryptod1.github.io";
    const origin = request.headers.get("Origin") || "";

    const cors = {
      "Access-Control-Allow-Origin": origin === allowedOrigin ? origin : allowedOrigin,
      "Access-Control-Allow-Methods": "POST,OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
      "Vary": "Origin",
      "Content-Type": "application/json"
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: cors });
    }

    const url = new URL(request.url);
    if (url.pathname !== "/api/resolve" || request.method !== "POST") {
      return json({ error: "Not found" }, 404, cors);
    }

    if (!env.OS_API_KEY) {
      return json({ error: "OS API key is not configured" }, 503, cors);
    }

    if (origin && origin !== allowedOrigin) {
      return json({ error: "Origin not allowed" }, 403, cors);
    }

    let body;
    try {
      body = await request.json();
    } catch {
      return json({ error: "Invalid JSON" }, 400, cors);
    }

    const property = clean(body.property);
    const postcode = cleanPostcode(body.postcode);

    if (!property || !postcode) {
      return json({ error: "property and postcode are required" }, 400, cors);
    }

    const query = `${property} ${postcode}`;
    const endpoint = new URL("https://api.os.uk/search/places/v1/find");
    endpoint.searchParams.set("query", query);
    endpoint.searchParams.set("maxresults", "20");
    endpoint.searchParams.set("dataset", "DPA");
    endpoint.searchParams.set("output_srs", "WGS84");
    endpoint.searchParams.set("key", env.OS_API_KEY);

    let osResponse;
    try {
      osResponse = await fetch(endpoint.toString(), {
        headers: { "Accept": "application/json" }
      });
    } catch {
      return json({ error: "Authoritative service unavailable" }, 502, cors);
    }

    if (!osResponse.ok) {
      return json({ error: "Authoritative service rejected request", upstream_status: osResponse.status }, 502, cors);
    }

    const payload = await osResponse.json();
    const rows = Array.isArray(payload.results) ? payload.results : [];

    const matches = rows
      .map(r => r && r.DPA ? r.DPA : null)
      .filter(Boolean)
      .filter(dpa => cleanPostcode(dpa.POSTCODE) === postcode)
      .filter(dpa => isExactPropertyMatch(property, dpa))
      .filter(dpa => dpa.UPRN && Number.isFinite(Number(dpa.LAT)) && Number.isFinite(Number(dpa.LNG)));

    // Breadcrumbs deliberately refuses ambiguity.
    if (matches.length !== 1) {
      return json({
        verified: false,
        reason: matches.length === 0 ? "no_unique_authoritative_match" : "ambiguous_authoritative_match",
        match_count: matches.length
      }, 200, cors);
    }

    const dpa = matches[0];
    return json({
      verified: true,
      source: "OS Places API",
      uprn: String(dpa.UPRN),
      address: dpa.ADDRESS || query,
      latitude: Number(dpa.LAT),
      longitude: Number(dpa.LNG),
      match: Number.isFinite(Number(dpa.MATCH)) ? Number(dpa.MATCH) : null
    }, 200, cors);
  }
};

function clean(v) {
  return String(v || "")
    .trim()
    .toUpperCase()
    .replace(/[’']/g, "")
    .replace(/[^A-Z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function cleanPostcode(v) {
  return String(v || "").toUpperCase().replace(/\s+/g, "");
}

function isExactPropertyMatch(property, dpa) {
  const wanted = clean(property);
  const building = clean(dpa.BUILDING_NAME);
  const subBuilding = clean(dpa.SUB_BUILDING_NAME);
  const address = clean(dpa.ADDRESS);

  if (building === wanted || subBuilding === wanted) return true;

  // Accept the name only when it appears as the leading address component,
  // avoiding loose substring matches such as "Cartref House" vs "Cartref".
  const firstPart = clean(String(dpa.ADDRESS || "").split(",")[0]);
  return firstPart === wanted && address.startsWith(wanted);
}

function json(data, status, headers) {
  return new Response(JSON.stringify(data), { status, headers });
}
